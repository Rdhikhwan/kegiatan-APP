<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('kegiatan', function (Blueprint $table) {
            $table->id(); // ID Kegiatan
            $table->string('judul', 200);
            $table->text('deskripsi');
            $table->string('jenis_media', 50);
            $table->date('tanggal_kegiatan');
            $table->time('durasi');
            $table->string('kategori_kegiatan', 100);
            $table->string('lokasi', 100);
            $table->string('upload_file', 255);
            $table->string('thumbnail', 255);
            $table->string('tags', 255);
            $table->string('tautan_tambahan', 255)->nullable();
            $table->enum('status_validasi', ['Y', 'N']);
            $table->enum('status_setuju', ['Y', 'N']);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('kegiatan');
    }
};
