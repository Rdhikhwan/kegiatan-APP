<?php

namespace App\Http\Controllers;

use App\Models\Kegiatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class KegiatanController extends Controller
{
    public function index()
    {
        $kegiatan = Kegiatan::all();

        return view('kegiatan.index', compact('kegiatan'));
    }

    public function create()
    {
        return view('kegiatan.create');
    }

    public function store(Request $request)
    {
        // Validasi input
        $validated = $request->validate([
            'judul' => 'required|string|max:200',
            'deskripsi' => 'nullable|string',
            'jenis_media' => 'required|string|max:50',
            'tanggal_kegiatan' => 'required|date',
            'durasi' => 'required',
            'kategori_kegiatan' => 'required|string|max:100',
            'lokasi' => 'required|string|max:100',
            'upload_file' => 'required|file|mimes:mp3,mp4,mov|max:20480', // max 20MB
            'thumbnail' => 'required|image|max:5120', // max 5MB
            'tags' => 'nullable|string|max:255',
            'tautan_tambahan' => 'nullable|url|max:255',
            'status_validasi' => 'required|in:Y',
            'status_setuju' => 'required|in:Y',
        ]);

        // Simpan file media
        $uploadPath = $request->file('upload_file')->store('uploads/files', 'public');
        $thumbnailPath = $request->file('thumbnail')->store('uploads/thumbnails', 'public');

        // Buat entri baru
        $kegiatan = new Kegiatan;
        $kegiatan->judul = $validated['judul'];
        $kegiatan->deskripsi = $validated['deskripsi'] ?? null;
        $kegiatan->jenis_media = $validated['jenis_media'];
        $kegiatan->tanggal_kegiatan = $validated['tanggal_kegiatan'];
        $kegiatan->durasi = $validated['durasi'];
        $kegiatan->kategori_kegiatan = $validated['kategori_kegiatan'];
        $kegiatan->lokasi = $validated['lokasi'];
        $kegiatan->upload_file = $uploadPath;
        $kegiatan->thumbnail = $thumbnailPath;
        $kegiatan->tags = $validated['tags'] ?? null;
        $kegiatan->tautan_tambahan = $validated['tautan_tambahan'] ?? null;
        $kegiatan->status_validasi = 'Y';
        $kegiatan->status_setuju = 'Y';
        $kegiatan->save();

        return redirect()->route('kegiatan.index')->with('success', 'Data kegiatan berhasil disimpan.');
    }

    public function edit(Kegiatan $kegiatan)
    {
        return view('kegiatan.edit', compact('kegiatan'));
    }

    public function update(Request $request, $id)
    {
        $kegiatan = Kegiatan::findOrFail($id);

        // Validasi sederhana (bisa dikembangkan)
        $validated = $request->validate([
            'judul' => 'required|string|max:200',
            'deskripsi' => 'nullable|string',
            'jenis_media' => 'required|string|max:50',
            'tanggal_kegiatan' => 'required|date',
            'durasi' => 'required',
            'kategori_kegiatan' => 'required|string|max:100',
            'lokasi' => 'required|string|max:100',
            'upload_file' => 'nullable|file|mimes:mp3,mp4,mov|max:20480', // max 20MB
            'thumbnail' => 'nullable|image|max:5120', // max 5MB
            'tags' => 'nullable|string|max:255',
            'tautan_tambahan' => 'nullable|url|max:255',
            'status_validasi' => 'required|in:Y',
            'status_setuju' => 'required|in:Y',
        ]);

        // Update field biasa
        $kegiatan->judul = $validated['judul'];
        $kegiatan->deskripsi = $validated['deskripsi'] ?? null;
        $kegiatan->jenis_media = $validated['jenis_media'];
        $kegiatan->tanggal_kegiatan = $validated['tanggal_kegiatan'];
        $kegiatan->durasi = $validated['durasi'];
        $kegiatan->kategori_kegiatan = $validated['kategori_kegiatan'];
        $kegiatan->lokasi = $validated['lokasi'];
        $kegiatan->tags = $validated['tags'] ?? null;
        $kegiatan->tautan_tambahan = $validated['tautan_tambahan'] ?? null;
        $kegiatan->status_validasi = 'Y'; // karena checkbox required dan must be Y
        $kegiatan->status_setuju = 'Y';

        // Handle upload_file
        if ($request->hasFile('upload_file')) {
            // Hapus file lama jika ada
            if ($kegiatan->upload_file && Storage::exists('public/'.$kegiatan->upload_file)) {
                Storage::delete('public/'.$kegiatan->upload_file);
            }
            $path = $request->file('upload_file')->store('uploads/files', 'public');
            $kegiatan->upload_file = $path;
        }

        // Handle thumbnail
        if ($request->hasFile('thumbnail')) {
            // Hapus thumbnail lama jika ada
            if ($kegiatan->thumbnail && Storage::exists('public/'.$kegiatan->thumbnail)) {
                Storage::delete('public/'.$kegiatan->thumbnail);
            }
            $path = $request->file('thumbnail')->store('uploads/thumbnails', 'public');
            $kegiatan->thumbnail = $path;
        }

        $kegiatan->save();

        return redirect()->route('kegiatan.index')->with('success', 'Data kegiatan berhasil diperbarui.');
    }

    public function destroy(Kegiatan $kegiatan)
    {
        $kegiatan->delete();

        return redirect()->route('kegiatan.index')->with('success', 'Data berhasil dihapus');
    }
}
