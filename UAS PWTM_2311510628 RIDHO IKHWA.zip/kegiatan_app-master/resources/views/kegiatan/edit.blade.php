
@extends('layouts.app')

@section('title', 'Ubah Kegiatan')

@section('content')
    <form action="{{ route('kegiatan.update', $kegiatan->id) }}" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow max-w-3xl">
        @csrf
        @method('PUT')

        {{-- Judul Kegiatan --}}
        <div class="mb-4">
            <label for="judul" class="block font-semibold mb-1">Judul Kegiatan</label>
            <input type="text" name="judul" id="judul" value="{{ old('judul', $kegiatan->judul) }}"
                class="w-full border border-gray-300 rounded px-3 py-2">
        </div>

        {{-- Deskripsi --}}
        <div class="mb-4">
            <label for="deskripsi" class="block font-semibold mb-1">Deskripsi Kegiatan</label>
            <textarea name="deskripsi" id="deskripsi" rows="4" class="w-full border border-gray-300 rounded px-3 py-2">{{ old('deskripsi', $kegiatan->deskripsi) }}</textarea>
        </div>

        {{-- Jenis Media --}}
        <div class="mb-4">
            <label for="jenis_media" class="block font-semibold mb-1">Jenis Media</label>
            <select name="jenis_media" id="jenis_media" class="w-full border border-gray-300 rounded px-3 py-2">
                @php
                    $mediaOptions = ['Video', 'Audio', 'Podcast', 'Dokumentasi Kegiatan'];
                @endphp
                <option value="">-- Pilih Jenis Media --</option>
                @foreach ($mediaOptions as $option)
                    <option value="{{ $option }}" {{ (old('jenis_media', $kegiatan->jenis_media) == $option) ? 'selected' : '' }}>
                        {{ $option }}
                    </option>
                @endforeach
            </select>
        </div>

        {{-- Tanggal Kegiatan --}}
        <div class="mb-4">
            <label for="tanggal_kegiatan" class="block font-semibold mb-1">Tanggal Kegiatan</label>
            <input type="date" name="tanggal_kegiatan" id="tanggal_kegiatan" value="{{ old('tanggal_kegiatan', $kegiatan->tanggal_kegiatan->format('Y-m-d')) }}" class="w-full border border-gray-300 rounded px-3 py-2">
        </div>

        {{-- Durasi --}}
        <div class="mb-4">
            <label for="durasi" class="block font-semibold mb-1">Durasi (hh:mm:ss)</label>
            <input type="time" step="1" name="durasi" id="durasi" value="{{ old('durasi', $kegiatan->durasi) }}" class="w-full border border-gray-300 rounded px-3 py-2">
        </div>

        {{-- Kategori --}}
        <div class="mb-4">
            <label for="kategori_kegiatan" class="block font-semibold mb-1">Kategori Kegiatan</label>
            <select name="kategori_kegiatan" id="kategori_kegiatan" class="w-full border border-gray-300 rounded px-3 py-2">
                @php
                    $kategoriOptions = ['Pelatihan', 'Workshop', 'Sosialisasi', 'Karya Kreatif'];
                @endphp
                <option value="">-- Pilih Kategori --</option>
                @foreach ($kategoriOptions as $option)
                    <option value="{{ $option }}" {{ (old('kategori_kegiatan', $kegiatan->kategori_kegiatan) == $option) ? 'selected' : '' }}>
                        {{ $option }}
                    </option>
                @endforeach
            </select>
        </div>

        {{-- Lokasi --}}
        <div class="mb-4">
            <label for="lokasi" class="block font-semibold mb-1">Lokasi</label>
            <select name="lokasi" id="lokasi" class="w-full border border-gray-300 rounded px-3 py-2">
                @php
                    $lokasiOptions = ['Kampus', 'Komunitas A', 'Virtual'];
                @endphp
                <option value="">-- Pilih Lokasi --</option>
                @foreach ($lokasiOptions as $option)
                    <option value="{{ $option }}" {{ (old('lokasi', $kegiatan->lokasi) == $option) ? 'selected' : '' }}>
                        {{ $option }}
                    </option>
                @endforeach
            </select>
        </div>
        {{-- Upload File --}}
        <div class="mb-4">
             <label for="upload_file" class="block font-semibold mb-1">Upload File (mp3/mp4/mov)</label>

            @if($kegiatan->upload_file)
                <p class="mb-2">
                    File saat ini:
                    <a href="{{ asset('storage/' . $kegiatan->upload_file) }}" target="_blank" class="text-blue-600 underline">
                        {{ basename($kegiatan->upload_file) }}
                    </a>
                </p>

                {{-- Preview player --}}
                @php
                    $extension = pathinfo($kegiatan->upload_file, PATHINFO_EXTENSION);
                    $fileUrl = asset('storage/' . $kegiatan->upload_file);
                @endphp

                @if(in_array($extension, ['mp4', 'mov']))
                    <video controls class="w-full max-w-md mb-2 rounded">
                        <source src="{{ $fileUrl }}" type="video/{{ $extension }}">
                        Your browser does not support the video tag.
                    </video>
                @elseif($extension === 'mp3')
                    <audio controls class="w-full mb-2">
                        <source src="{{ $fileUrl }}" type="audio/mpeg">
                        Your browser does not support the audio tag.
                    </audio>
                @endif
            @endif

            <input type="file" name="upload_file" id="upload_file" accept=".mp3,.mp4,.mov" class="w-full">
            <small class="text-gray-600">Upload file baru jika ingin mengganti file lama.</small>
        </div>

        {{-- Thumbnail --}}
        <div class="mb-4">
            <label for="thumbnail" class="block font-semibold mb-1">Thumbnail Cover</label>
            @if($kegiatan->thumbnail)
                <img src="{{ asset('storage/' . $kegiatan->thumbnail) }}" alt="Thumbnail Lama" id="thumbnailPreview" class="w-48 h-auto mb-2 rounded border">
            @else
                <img src="" alt="Preview Thumbnail" id="thumbnailPreview" class="hidden w-48 h-auto mb-2 rounded border">
            @endif
            <input type="file" name="thumbnail" id="thumbnail" accept="image/*" class="w-full">
        </div>

        {{-- Kata Kunci / Tag --}}
        <div class="mb-4">
            <label for="tags" class="block font-semibold mb-1">Kata Kunci / Tag (max 5, pisah koma)</label>
            <input type="text" name="tags" id="tags" value="{{ old('tags', $kegiatan->tags) }}" class="w-full border border-gray-300 rounded px-3 py-2" placeholder="contoh: workshop, pelatihan, teknologi">
        </div>

        {{-- Tautan Tambahan --}}
        <div class="mb-4">
            <label for="tautan_tambahan" class="block font-semibold mb-1">Tautan Tambahan (URL)</label>
            <input type="url" name="tautan_tambahan" id="tautan_tambahan" value="{{ old('tautan_tambahan', $kegiatan->tautan_tambahan) }}" class="w-full border border-gray-300 rounded px-3 py-2" placeholder="https://example.com">
        </div>

        {{-- Status Validasi --}}
        <div class="mb-4 flex items-center space-x-2">
            <input type="checkbox" name="status_validasi" id="status_validasi" value="Y" {{ old('status_validasi', $kegiatan->status_validasi) == 'Y' ? 'checked' : '' }} required>
            <label for="status_validasi" class="font-semibold">Status Validasi (Dokumentasi sah kegiatan sendiri)</label>
        </div>

        {{-- Status Setuju --}}
        <div class="mb-6 flex items-center space-x-2">
            <input type="checkbox" name="status_setuju" id="status_setuju" value="Y" {{ old('status_setuju', $kegiatan->status_setuju) == 'Y' ? 'checked' : '' }} required>
            <label for="status_setuju" class="font-semibold">Status Setuju (Izin tampil di sistem)</label>
        </div>

        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Update Kegiatan</button>
    </form>

    {{-- Script preview thumbnail --}}
    <script>
        document.getElementById('thumbnail').addEventListener('change', function(e) {
            const [file] = e.target.files;
            if (file) {
                const preview = document.getElementById('thumbnailPreview');
                preview.src = URL.createObjectURL(file);
                preview.classList.remove('hidden');
            }
        });
    </script>
@endsection
