
@extends('layouts.app')

@section('title', 'Tambah Kegiatan')

@section('content')
    <form action="{{ route('kegiatan.store') }}" method="POST" enctype="multipart/form-data" class="bg-white p-6 rounded shadow max-w-3xl">
        @csrf

        {{-- Judul Kegiatan --}}
        <div class="mb-4">
            <label for="judul" class="block font-semibold mb-1">Judul Kegiatan</label>
            <input type="text" name="judul" id="judul" value="{{ old('judul') }}"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('judul') border-red-500 @enderror">
            @error('judul')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Deskripsi --}}
        <div class="mb-4">
            <label for="deskripsi" class="block font-semibold mb-1">Deskripsi Kegiatan</label>
            <textarea name="deskripsi" id="deskripsi" rows="4"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('deskripsi') border-red-500 @enderror">{{ old('deskripsi') }}</textarea>
            @error('deskripsi')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Jenis Media --}}
        <div class="mb-4">
            <label for="jenis_media" class="block font-semibold mb-1">Jenis Media</label>
            <select name="jenis_media" id="jenis_media" class="w-full border border-gray-300 rounded px-3 py-2 @error('jenis_media') border-red-500 @enderror">
                <option value="">-- Pilih Jenis Media --</option>
                <option value="Video" {{ old('jenis_media') == 'Video' ? 'selected' : '' }}>Video</option>
                <option value="Audio" {{ old('jenis_media') == 'Audio' ? 'selected' : '' }}>Audio</option>
                <option value="Podcast" {{ old('jenis_media') == 'Podcast' ? 'selected' : '' }}>Podcast</option>
                <option value="Dokumentasi Kegiatan" {{ old('jenis_media') == 'Dokumentasi Kegiatan' ? 'selected' : '' }}>Dokumentasi Kegiatan</option>
            </select>
            @error('jenis_media')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Tanggal Kegiatan --}}
        <div class="mb-4">
            <label for="tanggal_kegiatan" class="block font-semibold mb-1">Tanggal Kegiatan</label>
            <input type="date" name="tanggal_kegiatan" id="tanggal_kegiatan" value="{{ old('tanggal_kegiatan') }}"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('tanggal_kegiatan') border-red-500 @enderror">
            @error('tanggal_kegiatan')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Durasi --}}
        <div class="mb-4">
            <label for="durasi" class="block font-semibold mb-1">Durasi (hh:mm:ss)</label>
            <input type="time" step="1" name="durasi" id="durasi" value="{{ old('durasi') }}"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('durasi') border-red-500 @enderror">
            @error('durasi')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Kategori Kegiatan --}}
        <div class="mb-4">
            <label for="kategori_kegiatan" class="block font-semibold mb-1">Kategori Kegiatan</label>
            <select name="kategori_kegiatan" id="kategori_kegiatan"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('kategori_kegiatan') border-red-500 @enderror">
                <option value="">-- Pilih Kategori --</option>
                <option value="Pelatihan" {{ old('kategori_kegiatan') == 'Pelatihan' ? 'selected' : '' }}>Pelatihan</option>
                <option value="Workshop" {{ old('kategori_kegiatan') == 'Workshop' ? 'selected' : '' }}>Workshop</option>
                <option value="Sosialisasi" {{ old('kategori_kegiatan') == 'Sosialisasi' ? 'selected' : '' }}>Sosialisasi</option>
                <option value="Karya Kreatif" {{ old('kategori_kegiatan') == 'Karya Kreatif' ? 'selected' : '' }}>Karya Kreatif</option>
            </select>
            @error('kategori_kegiatan')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Lokasi --}}
        <div class="mb-4">
            <label for="lokasi" class="block font-semibold mb-1">Lokasi</label>
            <select name="lokasi" id="lokasi"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('lokasi') border-red-500 @enderror">
                <option value="">-- Pilih Lokasi --</option>
                <option value="Kampus" {{ old('lokasi') == 'Kampus' ? 'selected' : '' }}>Kampus</option>
                <option value="Komunitas A" {{ old('lokasi') == 'Komunitas A' ? 'selected' : '' }}>Komunitas A</option>
                <option value="Virtual" {{ old('lokasi') == 'Virtual' ? 'selected' : '' }}>Virtual</option>
            </select>
            @error('lokasi')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Upload File (mp3/mp4/mov) --}}
        <div class="mb-4">
            <label for="upload_file" class="block font-semibold mb-1">Upload File (mp3/mp4/mov)</label>
            <input type="file" name="upload_file" id="upload_file" accept=".mp3,.mp4,.mov"
                class="w-full @error('upload_file') border-red-500 @enderror">
            @error('upload_file')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Thumbnail Cover --}}
        <div class="mb-4">
            <label for="thumbnail" class="block font-semibold mb-1">Thumbnail Cover</label>
            <input type="file" name="thumbnail" id="thumbnail" accept="image/*"
                class="w-full @error('thumbnail') border-red-500 @enderror">
            @error('thumbnail')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Kata Kunci / Tag --}}
        <div class="mb-4">
            <label for="tags" class="block font-semibold mb-1">Kata Kunci / Tag (max 5, pisah koma)</label>
            <input type="text" name="tags" id="tags" value="{{ old('tags') }}"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('tags') border-red-500 @enderror"
                placeholder="Contoh: workshop, pelatihan, teknologi">
            @error('tags')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Tautan Tambahan --}}
        <div class="mb-4">
            <label for="tautan_tambahan" class="block font-semibold mb-1">Tautan Tambahan (URL)</label>
            <input type="url" name="tautan_tambahan" id="tautan_tambahan" value="{{ old('tautan_tambahan') }}"
                class="w-full border border-gray-300 rounded px-3 py-2 @error('tautan_tambahan') border-red-500 @enderror"
                placeholder="https://example.com">
            @error('tautan_tambahan')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Status Validasi --}}
        <div class="mb-4 flex items-center space-x-2">
            <input type="checkbox" name="status_validasi" id="status_validasi" value="Y" {{ old('status_validasi') == 'Y' ? 'checked' : '' }} required>
            <label for="status_validasi" class="font-semibold">Status Validasi (Dokumentasi sah kegiatan sendiri)</label>
            @error('status_validasi')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        {{-- Status Setuju --}}
        <div class="mb-6 flex items-center space-x-2">
            <input type="checkbox" name="status_setuju" id="status_setuju" value="Y" {{ old('status_setuju') == 'Y' ? 'checked' : '' }} required>
            <label for="status_setuju" class="font-semibold">Status Setuju (Dikonfirmasi ketua)</label>
            @error('status_setuju')
                <p class="text-red-600 text-sm mt-1">{{ $message }}</p>
            @enderror
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Simpan Kegiatan
        </button>
    </form>
@endsection
              <p class=
