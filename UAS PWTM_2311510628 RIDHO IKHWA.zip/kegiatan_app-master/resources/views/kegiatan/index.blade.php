
@extends('layouts.app')

@section('title', 'Daftar Kegiatan')

@section('content')
    @if(session('success'))
        <div class="bg-green-200 text-green-800 px-4 py-2 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <table class="w-full bg-white rounded shadow">
        <thead>
            <tr class="bg-gray-200 text-left">
                <th class="px-4 py-2">Judul</th>
                <th class="px-4 py-2">Deskripsi</th>
                <th class="px-4 py-2">Tanggal</th>
                <th class="px-4 py-2">Lokasi</th>
                <th class="px-4 py-2">Thumbnail</th>
                <th class="px-4 py-2">Tags</th>
                <th class="px-4 py-2">Tautan</th>
                <th class="px-4 py-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            @foreach($kegiatan as $item)
                <tr class="border-t">
                    <td class="px-4 py-2">{{ $item->judul }}</td>
                    <td class="px-4 py-2">{{ Str::limit($item->deskripsi, 50) }}</td>
                    <td class="px-4 py-2">{{ $item->tanggal_kegiatan }}</td>
                    <td class="px-4 py-2">{{ $item->lokasi }}</td>
                    <td class="px-4 py-2">
                        <img src="{{ asset('storage/' . $item->thumbnail) }}" alt="" class="w-16 h-16 object-cover rounded">
                    </td>
                    <td class="px-4 py-2">{{ $item->tags }}</td>
                    <td class="px-4 py-2">
                        @if($item->tautan_tambahan)
                            <a href="{{ $item->tautan_tambahan }}" target="_blank" class="text-blue-600 underline">Link</a>
                        @endif
                    </td>
                    <td class="px-4 py-2 space-x-2">
                        <a href="{{ route('kegiatan.edit', $item) }}" class="bg-yellow-400 px-2 py-1 rounded text-white">Ubah</a>
                        <form action="{{ route('kegiatan.destroy', $item) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" onclick="return confirm('Yakin hapus?')" class="bg-red-500 px-2 py-1 rounded text-white">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
@endsection
