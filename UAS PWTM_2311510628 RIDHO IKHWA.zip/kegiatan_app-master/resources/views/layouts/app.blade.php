
<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kegiatan</title>
    @vite('resources/css/app.css')
</head>
<body class="bg-gray-100 h-full">
    <div class="flex h-screen">
        {{-- Sidebar --}}
        <aside class="w-64 bg-blue-800 text-white flex flex-col p-4">
            <h1 class="text-2xl font-bold mb-4">Admin Panel</h1>
            <nav class="flex-1 space-y-2">
                <a href="{{ route('kegiatan.index') }}" class="block py-2 px-3 rounded hover:bg-blue-700">Data Kegiatan</a>
                <a href="{{ route('kegiatan.create') }}" class="block py-2 px-3 rounded hover:bg-blue-700">Tambah Kegiatan</a>
            </nav>
            <footer class="mt-auto text-sm text-gray-300">
                © {{ date('Y') }} - UBL
            </footer>
        </aside>

        {{-- Content --}}
        <main class="flex-1 p-6 overflow-y-auto">
            {{-- Header --}}
            <header class="mb-4">
                <h2 class="text-xl font-semibold text-gray-800">@yield('title', 'Dashboard')</h2>
            </header>

            {{-- Page Content --}}
            @yield('content')
        </main>
    </div>
</body>
</html>
